package src.saida;

import src.Instrucao;

public class Print extends Instrucao {

    public Print() {

    }

    @Override
    public void executar() {

    }

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}
