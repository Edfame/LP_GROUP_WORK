package src.saida;

import src.Instrucao;

public class PrintNl extends Instrucao {

    public PrintNl() {

    }

    @Override
    public void executar() {

    }

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}
