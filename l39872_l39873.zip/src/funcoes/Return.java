package src.funcoes;

import src.Instrucao;

public class Return extends Instrucao {

    public Return() {

    }

    @Override
    public void executar() {

    }

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}
