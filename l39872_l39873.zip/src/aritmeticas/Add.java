package src.aritmeticas;

import src.Instrucao;

public class Add extends Instrucao {

    public Add() {

    }

    @Override
    public void executar() {

    }

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}
