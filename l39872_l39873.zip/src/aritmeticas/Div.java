package src.aritmeticas;

import src.Instrucao;

public class Div extends Instrucao {

    public Div() {

    }

    @Override
    public void executar() {

    }

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}