package src.aritmeticas;

import src.Instrucao;

public class Mult extends Instrucao {

    public Mult() {

    }

    @Override
    public void executar() {

    }

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}