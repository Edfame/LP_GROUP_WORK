package src.aritmeticas;

import src.Instrucao;

public class Sub extends Instrucao {

    public Sub() {

    }

    @Override
    public void executar() {

    }

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}
