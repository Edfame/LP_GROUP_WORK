package src.aritmeticas;

import src.Instrucao;

public class Mod extends Instrucao {

    public Mod() {

    }

    @Override
    public void executar() {

    }

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}