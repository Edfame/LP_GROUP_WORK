package src;

public abstract class Instrucao {

    public abstract void executar();

    public abstract String toString();
}
