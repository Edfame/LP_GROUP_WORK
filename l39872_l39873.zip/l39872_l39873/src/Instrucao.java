package src;

public abstract class Instrucao {

    public abstract void executar(TISC tisc);

    public abstract String toString();
}
